package com.amazon.customskill;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.amazon.customskill.AlexaSkillSpeechlet.RecognitionState;
//import com.amazon.customskill.AlexaSkillSpeechlet.UserIntent;
import com.amazon.speech.json.SpeechletRequestEnvelope;
import com.amazon.speech.slu.Intent;
import com.amazon.speech.speechlet.IntentRequest;
import com.amazon.speech.speechlet.LaunchRequest;
import com.amazon.speech.speechlet.SessionEndedRequest;
import com.amazon.speech.speechlet.SessionStartedRequest;
import com.amazon.speech.speechlet.SpeechletResponse;
import com.amazon.speech.speechlet.SpeechletV2;
import com.amazon.speech.ui.PlainTextOutputSpeech;
import com.amazon.speech.ui.Reprompt;
import com.amazon.speech.ui.SsmlOutputSpeech;



/*
 * This class is the actual skill. Here you receive the input and have to produce the speech output. 
 */
public class AlexaSkillSpeechlet
implements SpeechletV2
{
	static Logger logger = LoggerFactory.getLogger(AlexaSkillSpeechlet.class);

	public static String userRequest;

	//Unsere Variablen


	private static int sum;
	private static String question = "";
	private static enum RecognitionState {Dish, Ingredient, YesNo};
	private RecognitionState recState;

	private static enum UserIntentYesNo {Yes, No};
	private static enum UserIntentDish {Pasta, Potatoes, Fehler};

	private static enum UserIntentIngredient {
		Potatoes(false),
		Pasta(false), 
		Tomatoes(false), 
		Onions(false),
		Error(false);

		private boolean alreadyUsed;

		private UserIntentIngredient(boolean alreadyUsed) {
			this.alreadyUsed = alreadyUsed;
		}

		private boolean getAlreadyUsed() {
			return alreadyUsed;
		}


		private void setAlreadyUsed(boolean alreadyUsed) {
			this.alreadyUsed = alreadyUsed;
		}

	}; 

	UserIntentDish ourDish;
	UserIntentIngredient ourIngredient;
	UserIntentYesNo ourYesNo;



	//Feste Texte
	static String welcomeMsg = "Hello! You want to cook something for a group of friends tonight. Frankly you don't have anything left in the fridge, so you need to go to the marktet to get last minute ingridients. You can choose between pasta with tomato sauce or potatoes with spinach. What would you like to cook?";
	static String continueMsg = "Would you like to buy something else?";
	static String gotItMsg = "Thank you. I'll add it to your cart.";
	static String goodbyeMsg = "I hope you liked your experience at the best market in town.";
	static String priceMsg = "Thank you, that makes " + (sum) + "pounds please.";
	static String errorIngridients = "I didn't catch that. Which ingridient do you want?";
	static String errorYesNoMsg = "Can you repeat that?";
	static String ingridientUsedMsg = "You already bought this ingridient.";
	static String toTheMarketMsg = "Great! You'll need 500 gramms of pasta and 5 tomatoes. Let me guide you to the market!";
	static String toTheMarketMsgPotatoes = "Great! You'll need 500 gramms of potatoes and 1000 gramms of spinach. Let me guide you to the market!";
	@Override
	public void onSessionStarted(SpeechletRequestEnvelope<SessionStartedRequest> requestEnvelope)
	{
		logger.info("Alexa session begins");
		sum = 0;
		recState = RecognitionState.Dish;
	}

	//Wenn das Programm startet 

	@Override
	public SpeechletResponse onLaunch(SpeechletRequestEnvelope<LaunchRequest> requestEnvelope)
	{
		logger.info("onLaunch wird ausgeführt");
		sum = 0;
		selectQuestion();
		return askUserResponse(welcomeMsg);
	}

	// Nach jedem Einkauf wird eine neue Frage nach einer Zutat gefragt

	private void selectQuestion() {
		logger.info("in selectQuestion, sum is" + sum);
		switch(sum){
		case 0: question = "Hey! Welcome to the best market in town. How can I help you?"; break; //hier fehlte nur das "break"
		case 1: question = "What would you like?"; break;
		case 2: question = "Nice Choice?"; break;
		case 3: question = "What would you like?"; break;

		}
	}

	@Override
	public SpeechletResponse onIntent(SpeechletRequestEnvelope<IntentRequest> requestEnvelope)
	{
		IntentRequest request = requestEnvelope.getRequest();
		Intent intent = request.getIntent();
		userRequest = intent.getSlot("anything").getValue();
		logger.info("Received following text: [" + userRequest + "]");
		logger.info("recState is [" + recState + "]");
		SpeechletResponse resp = null;
		
		switch (recState) {
		// TODO: Wie aendern sich die recognitionstates abhaengig vom userinput?
			case Dish: {
				//recState = RecognitionState.Ingredient;
				resp = evaluateDish(userRequest); // Gericht ausw�hlen (Pasta / Potatoes)
				break;
			}
			case Ingredient: evaluateIngredient(userRequest); break;
			case YesNo: resp = evaluateYesNo(userRequest); break;
			default: resp = response("Please choose your ingredients now "); // + userRequest);
		}   
		return resp;
	}

	private SpeechletResponse evaluateDish(String userRequest) {
		SpeechletResponse res = null;
		recognizeUserIntent(userRequest);
		switch(ourDish) {
		case Pasta: {
			selectQuestion();
			res = askUserResponse(toTheMarketMsg + question); break;	
			
		}
		case Fehler: {
			selectQuestion();
			res = askUserResponse(errorIngridients); break;
		}
		case Potatoes: {
			selectQuestion();
			res = askUserResponse(toTheMarketMsgPotatoes + question); break;
			
		}
		
		}
		return res;
	}
	
	// Falls der Nutzer mehr einkaufen m�chte (yes), fragt Alexa eine neue Frage
	// Falls der Nutzer nichts mehr m�chte (no), gibt Alexa die Summe der Zutaten aus und die Verabschiedung

	private SpeechletResponse evaluateYesNo(String userRequest) {
		SpeechletResponse res = null;
		recognizeUserIntent(userRequest);
		switch (ourYesNo) {
		case Yes: {
			selectQuestion();
			res = askUserResponse(question); break;
		} case No: {
			res = response(buildString(priceMsg, String.valueOf(sum), "")+" "+goodbyeMsg); break;
		} default: {
			res = askUserResponse(errorYesNoMsg);
		}
		}
		return res;
	}

	// Wenn der Nutzer eine Zutat sagt, erkennt Alexa, ob die Zutat schon eingekauft wurde


	private SpeechletResponse evaluateIngredient(String userRequest) {
		SpeechletResponse res = null;
		recognizeUserIntent(userRequest);
		
		//res = askUserResponse("Stage is evaluateIngredients");
		//ourIngredient = UserIntentIngredient.Error;
		switch (ourIngredient) {
			case Potatoes: {
				if (UserIntentIngredient.Onions.getAlreadyUsed() == true) {
					res = askUserResponse(ingridientUsedMsg);
				} else {
				UserIntentIngredient.Tomatoes.setAlreadyUsed(true);
				res = askUserResponse((gotItMsg+" "+question));
				}
			}
			default: res = askUserResponse("Please choose");
	
		}
		return res;
	}


	//Summe wird hochgerechnet
	//TODO das funktioniert so nicht
	//TODO wird nie aufgerufen
	private void increaseSum() {
		switch(sum){
		case 0: sum = 1; break;
		case 1: sum = 3; break;
		case 3: sum = 5; break;
		case 5: sum = 10; break;

		}
	}

	//Unsere Patterns

	void recognizeUserIntent(String userRequest) {
		userRequest = userRequest.toLowerCase();
		String pattern1 = "(I'll have )?(some )?(a few )?(\\bpasta\\b)( please)?";
		String pattern2= "\\bpotatoes\\b";
		String pattern3= "\\byes\\b";
		String pattern4= "\\bonions\\b";
		String pattern5= "\\btomatoes\\b";

		Pattern p1 = Pattern.compile(pattern1);
		Matcher m1 = p1.matcher(userRequest);
		Pattern p2 = Pattern.compile(pattern2);
		Matcher m2 = p2.matcher(userRequest);
		Pattern p3 = Pattern.compile(pattern3);
		Matcher m3 = p3.matcher(userRequest);
		Pattern p4 = Pattern.compile(pattern4);
		Matcher m4 = p4.matcher(userRequest);
		Pattern p5 = Pattern.compile(pattern5);
		Matcher m5 = p5.matcher(userRequest);

		// TODO alle Intents auf Error setzen
		
		ourDish = UserIntentDish.Fehler;
		
		if (m1.find()) {

			ourDish = UserIntentDish.Pasta;
			logger.info("set ourIngredient to " +ourIngredient);
		} 
		else if (m2.find()) {
			ourDish = UserIntentDish.Potatoes;
			logger.info("set ourIngredient to " +ourIngredient);
		}
		else if (m3.find()) {
			ourYesNo = UserIntentYesNo.Yes;
			logger.info("set ourIngredient to " +ourIngredient);
		}
		else if (m4.find()) {
			ourIngredient = UserIntentIngredient.Onions;
			logger.info("set ourIngredient to " +ourIngredient);
		}
		else if (m5.find()) {
			ourIngredient = UserIntentIngredient.Tomatoes;
			logger.info("set ourIngredient to " +ourIngredient);
		}
	}


	@Override
	public void onSessionEnded(SpeechletRequestEnvelope<SessionEndedRequest> requestEnvelope)
	{
		logger.info("Alexa session ends now");
	}

	private SpeechletResponse askUserResponse(String text)
	{
		SsmlOutputSpeech speech = new SsmlOutputSpeech();
		if (text == welcomeMsg) {
			speech.setSsml("<speak><voice name='Kendra'>" + text + "</voice></speak>");
		} else {
			speech.setSsml("<speak>" + text + "</speak>");
		}

		// reprompt after 8 seconds
		SsmlOutputSpeech repromptSpeech = new SsmlOutputSpeech();
		repromptSpeech.setSsml("<speak><emphasis level=\"strong\">Hey!</emphasis> Are you still there?</speak>");

		Reprompt rep = new Reprompt();
		rep.setOutputSpeech(repromptSpeech);

		return SpeechletResponse.newAskResponse(speech, rep);
	}

	private SpeechletResponse response(String text)
	{
		// Create the plain text output.
		PlainTextOutputSpeech speech = new PlainTextOutputSpeech();
		speech.setText(text);

		return SpeechletResponse.newTellResponse(speech);
	}
	private String buildString(String msg, String replacement1, String replacement2) {
		return msg.replace("{replacement}", replacement1).replace("{replacement2}", replacement2);
	}
}