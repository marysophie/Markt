Schritte, um den Code auf Alexa zum Laufen zu bekommen:

1. Tomcat starten und im Manager die myskill.war Datei einf�gen (befindet sich in dem Ordner unter target)

2. ngrok starten und die https Adresse in den Endpoint des Alexa-Skills inder Alexa Console eingeben

3. Den Skill mit dem Skillnamen aufrufen, um den Skill zu starten