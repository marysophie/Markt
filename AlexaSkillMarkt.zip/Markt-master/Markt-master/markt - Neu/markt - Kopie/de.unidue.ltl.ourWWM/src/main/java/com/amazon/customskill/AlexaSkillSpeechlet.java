package com.amazon.customskill;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.amazon.customskill.AlexaSkillSpeechlet.RecognitionState;
//import com.amazon.customskill.AlexaSkillSpeechlet.UserIntent;
import com.amazon.speech.json.SpeechletRequestEnvelope;
import com.amazon.speech.slu.Intent;
import com.amazon.speech.speechlet.IntentRequest;
import com.amazon.speech.speechlet.LaunchRequest;
import com.amazon.speech.speechlet.SessionEndedRequest;
import com.amazon.speech.speechlet.SessionStartedRequest;
import com.amazon.speech.speechlet.SpeechletResponse;
import com.amazon.speech.speechlet.SpeechletV2;
import com.amazon.speech.ui.PlainTextOutputSpeech;
import com.amazon.speech.ui.Reprompt;
import com.amazon.speech.ui.SsmlOutputSpeech;



/*
 * This class is the actual skill. Here you receive the input and have to produce the speech output. 
 */
public class AlexaSkillSpeechlet
implements SpeechletV2
{
	static Logger logger = LoggerFactory.getLogger(AlexaSkillSpeechlet.class);

	public static String userRequest;

	//Unsere Variabeln und Intents



	private static int sum;
	private static String question = "";
	private static enum RecognitionState {Dish, Ingredient, YesNo, Others};
	private RecognitionState recState;

	private static enum UserIntentYesNo {Yes, No, Pasta, Onions, Spinach, Tomatoes, Potatoes, Recipe, Nevermind, Fehler};
	private static enum UserIntentDish {Pasta, Potatoes, Fehler};
	private static enum UserIntentOthers {Thanks, Bye,RecipePasta, RecipePotatoes, Fehler};

	// Damit das Programm erkennt, ob eine Zutat bereits eingekauft wurde, werden alle Zutaten auf false gesetzt
	
	private static enum UserIntentIngredient {
		Potatoes(false),
		Pasta(false), 
		Tomatoes(false), 
		Onions(false),
		Spinach(false),
		Fehler(false),
		Nevermind(false),
		Recipe(false);
		
		// Wenn die Zutat bereits gekauft wurde, wird diese auf alreadyUsed gesetzt
		
		private boolean alreadyUsed;
		
		private UserIntentIngredient(boolean alreadyUsed) {
			this.alreadyUsed = alreadyUsed;
		}

		private boolean getAlreadyUsed() {
			return alreadyUsed;
		}


		private void setAlreadyUsed(boolean alreadyUsed) {
			this.alreadyUsed = alreadyUsed;
		}

	}; 

	UserIntentDish ourDish;
	UserIntentIngredient ourIngredient;
	UserIntentYesNo ourYesNo;
	UserIntentOthers ourOthers;


	//Feste Texte, die bei verschiedenen User Intents aufgerufen werden
	
	static String welcomeMsg = "Hello! You want to cook something for a group of friends tonight. Frankly you don't have anything left in the fridge, so you need to go to the market to get last minute ingredients. You can choose between pasta with tomato sauce or potatoes with spinach. Which meal would you like to cook?";
	static String continueMsg = " Would you like to buy something else?";
	static String whichRecipe = "No Problem, which recipe would you like to hear again?";
	static String recipeMsgPotatoes = "You'll need 500 gramms of potatoes and 1000 gramms of spinach.";
	static String recipeMsgPasta = "You'll need 500 gramms of pasta, 5 tomatoes and 2 small onions.";
	static String whatIsIt = " Which delicious ingredient can I get for you now?";
	static String gotItMsg1 = "Thank you. I'll add the ";
	static String gotItMsg2 = " to your cart.<audio src=\"soundbank://soundlibrary/air/fire_extinguisher/fire_extinguisher_05\"/>";	
	static String goodbyeMsg = "I hope you liked your experience at the best market in town. See ya. Have a nice day!";
	static String priceMsg = "Thank you, your total is 6 pounds.";
	static String errorIngredients = "Sorry, I didn't catch that. ";
	static String errorYesNoMsg = "Sorry, Could you repeat that?";
	static String errorDish = "You don't have a recipe for that dish";
	static String ingridientUsedMsg = "You already bought this ingredient. Which one do you want instead?";
	static String toTheMarketMsg = "Great choice! You'll need 500 gramms of pasta, 5 tomatoes and 2 small onions. Don't worry, you can always ask for the recipe if you forget it. Let me guide you to the market!";
	static String toTheMarketMsgPotatoes = "Nice Choice! You'll need 500 gramms of potatoes and 1000 gramms of spinach. Don't worry, you can always ask for the recipe if you forget it. Let me guide you to the market!";
	@Override
	
	//Wenn die Session gestartet wird, wird zun�chst der Recognition State "Dish" aufgerufen, damit der Nutzer ein Gericht ausw�hlen kann
	
	public void onSessionStarted(SpeechletRequestEnvelope<SessionStartedRequest> requestEnvelope)
	{
		logger.info("Alexa session begins");
		sum = 0;
		recState = RecognitionState.Dish;
	}

	//Wenn das Programm startet, wird die Willkommennachricht ausgegeben

	@Override
	public SpeechletResponse onLaunch(SpeechletRequestEnvelope<LaunchRequest> requestEnvelope)
	{
		logger.info("onLaunch wird ausgeführt");
		sum = 0;
		selectQuestion();
		return askUserResponse(welcomeMsg);
	}

	// Nach jedem Einkauf wird eine neue Frage nach einer Zutat gefragt
	// Hier wurde eine Marktatmosph�re als Sound hinzugef�gt

	private void selectQuestion() {
		logger.info("in selectQuestion, sum is" + sum);
		switch(sum){
		case 0: question = "<audio src=\"soundbank://soundlibrary/backgrounds_ambience/bars_restaurants/bars_restaurants_05\"/>Hey. Welcome to the best market in town. We have a large variety of fruits, vegetables and more. What would you like to buy on such a beautiful sunny day?"; break;
		

		}
	}

	
	//Hier sind unsere Recognition States festgelegt 
	@Override
	public SpeechletResponse onIntent(SpeechletRequestEnvelope<IntentRequest> requestEnvelope)
	{
		IntentRequest request = requestEnvelope.getRequest();
		Intent intent = request.getIntent();
		userRequest = intent.getSlot("anything").getValue();
		logger.info("Received following text: [" + userRequest + "]");
		logger.info("recState is [" + recState + "]");
		SpeechletResponse resp = null;
		
		switch (recState) {
			case Dish: {
				resp = evaluateDish(userRequest); // Gericht ausw�hlen (Pasta / Potatoes)
				recState = RecognitionState.Ingredient;
				break;
			}
			case Ingredient: resp = evaluateIngredient(userRequest); break;
			case YesNo: resp = evaluateYesNo(userRequest); break;
			case Others: resp = evaluateOthers(userRequest); break;
			default: resp = response("Please choose your ingredients now "); 
		}   
		return resp;
	}
	
	//Hier kann das Gericht ausgew�hlt werden
	
	private SpeechletResponse evaluateDish(String userRequest) {
		SpeechletResponse res = null;
		recognizeUserIntent(userRequest);
		switch(ourDish) {
		case Pasta: {
			selectQuestion();
			res = responseWithFlavour(toTheMarketMsg + question,5); break;	
			
		}
		
		case Potatoes: {
			selectQuestion();
			res = responseWithFlavour(toTheMarketMsgPotatoes + question,5); break;
			
		}
		case Fehler: {
			selectQuestion();
			res = responseWithFlavour(errorDish, 2); break;
		}
		
		}
		return res;
	}
	
	

	//Hier werden die Zutaten ausgew�hlt
	//Wenn sie bereits ausgew�hlt wurden, wird es dem Nutzer mitgeteilt
	//Die verschiedenen Stimmen sind hier mit implementiert
	
	private SpeechletResponse evaluateIngredient(String userRequest) {
		SpeechletResponse res = null;
		recognizeUserIntent(userRequest);
		
	
		switch (ourIngredient) {
			case Onions: {
				if (UserIntentIngredient.Onions.getAlreadyUsed() == true) {
				res = responseWithFlavour(ingridientUsedMsg, 2); break;
				} else {
				UserIntentIngredient.Onions.setAlreadyUsed(true);
				res = responseWithFlavour((gotItMsg1+"onions"+ gotItMsg2 + "" + continueMsg), 1);
				recState = RecognitionState.YesNo;
				break;
				} 
			
			}
			case Tomatoes: {
				if (UserIntentIngredient.Tomatoes.getAlreadyUsed() == true) {
					res = responseWithFlavour(ingridientUsedMsg, 2); break;
				} else {
				UserIntentIngredient.Tomatoes.setAlreadyUsed(true);
				res = responseWithFlavour((gotItMsg1+"tomatoes"+ gotItMsg2 + "" + continueMsg), 1);
				recState = RecognitionState.YesNo; 
				sum += 1;
				break;
				}
			}
			case Pasta: {
				if (UserIntentIngredient.Pasta.getAlreadyUsed() == true) {
					res = responseWithFlavour(ingridientUsedMsg, 2); break;
				} else {
				UserIntentIngredient.Pasta.setAlreadyUsed(true);
				res = responseWithFlavour((gotItMsg1+"pasta"+ gotItMsg2 + "" +continueMsg), 1);
				recState = RecognitionState.YesNo; 
				sum +=1;
				break;
				} 
			}
			
			case Potatoes: {
				if (UserIntentIngredient.Potatoes.getAlreadyUsed() == true) {
					res = responseWithFlavour(ingridientUsedMsg, 1); break;
				} else {
				UserIntentIngredient.Potatoes.setAlreadyUsed(true);
				res = responseWithFlavour((gotItMsg1+"potatoes"+ gotItMsg2 + "" + continueMsg), 1);
				recState = RecognitionState.YesNo; break;
				} 
			}
			case Spinach: {
				if (UserIntentIngredient.Spinach.getAlreadyUsed() == true) {
					res = responseWithFlavour(ingridientUsedMsg, 1);
					break;
				} else {
				UserIntentIngredient.Spinach.setAlreadyUsed(true);
				res = responseWithFlavour((gotItMsg1+"spinach"+ gotItMsg2 + "" + continueMsg), 1);
				recState = RecognitionState.YesNo; break;
				} 
			}
			case Recipe: {
				res = responseWithFlavour(whichRecipe, 3);
				recState = RecognitionState.Others; break;
			}
			
			case Fehler: {
				
			res = responseWithFlavour(errorIngredients, 2);
			
			}
			default: res = responseWithFlavour(errorIngredients, 2);
	
		}
		return res;
	}
	
	//Das Programm wird beendet, wenn der Nutzer den Intent "NO" aufruft
	
		private SpeechletResponse evaluateYesNo(String userRequest) {
			SpeechletResponse res = null;
			recognizeUserIntent(userRequest);
			switch (ourYesNo) {
			//Falls Ja und Nein geantwortet wird
			case Yes: {
				selectQuestion();
				res = responseWithFlavour(whatIsIt, 2); 
				recState = RecognitionState.Ingredient; break;
			} case No: {
				res = responseWithFlavour(buildString(priceMsg, String.valueOf(sum), "")+" "+goodbyeMsg, 5);
				recState = RecognitionState.Others; break;
				
		//Falls ja oder eine neue Zutat genannt wird
				
			} case Pasta: {
				if (UserIntentIngredient.Pasta.getAlreadyUsed() == true) {
					res = responseWithFlavour(ingridientUsedMsg, 2); break;
				} else {
				UserIntentIngredient.Pasta.setAlreadyUsed(true);
				res = responseWithFlavour((gotItMsg1+"pasta"+ gotItMsg2 + "" +continueMsg), 1);
				recState = RecognitionState.YesNo; break;
				} 
			}
			case Onions: {
				if (UserIntentIngredient.Onions.getAlreadyUsed() == true) {
					res = responseWithFlavour(ingridientUsedMsg, 2); break;
				} else {
				UserIntentIngredient.Onions.setAlreadyUsed(true);
				res = responseWithFlavour((gotItMsg1+"onions"+ gotItMsg2 + "" + continueMsg), 1);
				recState = RecognitionState.YesNo;
				break;
				}
			}
			case Potatoes: {
				if (UserIntentIngredient.Potatoes.getAlreadyUsed() == true) {
					res = responseWithFlavour(ingridientUsedMsg, 2); break;
				} else {
				UserIntentIngredient.Potatoes.setAlreadyUsed(true);
				res = responseWithFlavour((gotItMsg1+"potatoes"+ gotItMsg2 + "" + continueMsg), 1);
				recState = RecognitionState.YesNo; break;
				} 
			}
			case Spinach: {
				if (UserIntentIngredient.Spinach.getAlreadyUsed() == true) {
					res = responseWithFlavour(ingridientUsedMsg,2);
					sum += 1;
					break;
				} else {
				UserIntentIngredient.Spinach.setAlreadyUsed(true);
				res = responseWithFlavour((gotItMsg1+"spinach"+ gotItMsg2 + "" + continueMsg), 1);
				recState = RecognitionState.YesNo; break;
				} 
			}
			case Tomatoes: {
				if (UserIntentIngredient.Tomatoes.getAlreadyUsed() == true) {
					res = responseWithFlavour(ingridientUsedMsg, 2); break;
				} else {
				UserIntentIngredient.Tomatoes.setAlreadyUsed(true);
				res = responseWithFlavour((gotItMsg1+"tomatoes"+ gotItMsg2 + "" + continueMsg), 1);
				recState = RecognitionState.YesNo; 
				sum += 1;
				break;
				}
			}
			case Recipe: {
				res = responseWithFlavour(whichRecipe, 3);
				recState = RecognitionState.Others; break;
			}
			case Nevermind: {
				res = responseWithFlavour(continueMsg, 2);
				recState = RecognitionState.YesNo;
			}
			
			
			case Fehler: {
				res = responseWithFlavour(errorYesNoMsg, 1);
			}
			
			
			default: {
				res = responseWithFlavour(errorYesNoMsg, 1);
			}
			}
			return res;
		}
		
	//Verabschiedung und Programmstop
	//Au�erdem die Hilfestellung, falls das Rezept vergessen wurde
		
	private SpeechletResponse evaluateOthers(String userRequest) {
		SpeechletResponse res = null;
		recognizeUserIntent(userRequest);
		
		//res = askUserResponse("Stage is evaluateIngredients");
		switch (ourOthers) {
			case Thanks: {
				res = responseWithFlavour("You're welcome",5); break;
			}
			case Bye: {
				res = responseWithFlavour("Have a nice day.",5); break;
			}
			case RecipePasta: {
				res = responseWithFlavour(recipeMsgPasta , 3);
				
				recState = RecognitionState.YesNo; break;
			}
			case RecipePotatoes: {
				res = responseWithFlavour(recipeMsgPotatoes , 3);
				res = askUserResponse ("Would you like to buy anything else then?");
				
				recState = RecognitionState.YesNo; break;
			}
			case Fehler: {
				
				res = askUserResponse("Sorry?");
			}
				default: res = askUserResponse("Sorry?");
			}
		return res;
	}


	//Unsere Patterns

	void recognizeUserIntent(String userRequest) {
		userRequest = userRequest.toLowerCase();
		String pattern1 = "(I'll have )?(some )?(a few )?(\\bpasta\\b)( please)?";
		String pattern2= "\\bpotatoes\\b";
		String pattern3= "\\bonions\\b";
		String pattern4= "\\btomatoes\\b";
		String pattern5= "\\bspinach\\b";
		String pattern6= "\\bno\\b";
		String pattern7= "\\byes\\b";
		String pattern8= "\\bthanks\\b";
		String pattern9= "\\brecipe\\b"; 
		String pattern10= "\\bnevermind\\b";
		
		
		
		
		Pattern p1 = Pattern.compile(pattern1);
		Matcher m1 = p1.matcher(userRequest);
		Pattern p2 = Pattern.compile(pattern2);
		Matcher m2 = p2.matcher(userRequest);
		Pattern p3 = Pattern.compile(pattern3);
		Matcher m3 = p3.matcher(userRequest);
		Pattern p4 = Pattern.compile(pattern4);
		Matcher m4 = p4.matcher(userRequest);
		Pattern p5 = Pattern.compile(pattern5);
		Matcher m5 = p5.matcher(userRequest);
		Pattern p6 = Pattern.compile(pattern6);
		Matcher m6 = p6.matcher(userRequest);
		Pattern p7 = Pattern.compile(pattern7);
		Matcher m7 = p7.matcher(userRequest);
		Pattern p8 = Pattern.compile(pattern8);
		Matcher m8 = p8.matcher(userRequest);
		Pattern p9 = Pattern.compile(pattern9);
		Matcher m9 = p9.matcher(userRequest);
		Pattern p10 = Pattern.compile(pattern10);
		Matcher m10 = p10.matcher(userRequest);
	

		
		
		ourDish = UserIntentDish.Fehler;
		ourIngredient = UserIntentIngredient.Fehler;
		ourYesNo = UserIntentYesNo.Fehler;
		ourOthers = UserIntentOthers.Fehler;
	
		
		if (m1.find()) {

			ourDish = UserIntentDish.Pasta;
			ourIngredient = UserIntentIngredient.Pasta;
			ourYesNo = UserIntentYesNo.Pasta;
			ourOthers = UserIntentOthers.RecipePasta;
			logger.info("set ourIngredient to " +ourIngredient);
		} 
		else if (m2.find()) {
			ourDish = UserIntentDish.Potatoes;
			ourIngredient = UserIntentIngredient.Potatoes;
			ourYesNo = UserIntentYesNo.Potatoes;
			ourOthers = UserIntentOthers.RecipePotatoes;
			logger.info("set ourIngredient to " +ourIngredient);
		}
		else if (m3.find()) {
			ourIngredient = UserIntentIngredient.Onions;
			ourYesNo = UserIntentYesNo.Onions;
			logger.info("set ourIngredient to " +ourIngredient);
		}
		else if (m4.find()) {
			ourIngredient = UserIntentIngredient.Tomatoes;
			ourYesNo = UserIntentYesNo.Tomatoes;
			logger.info("set ourIngredient to " +ourIngredient);
		}
		else if (m5.find()) {
			ourIngredient = UserIntentIngredient.Spinach;
			ourYesNo = UserIntentYesNo.Spinach;
			logger.info("set ourIngredient to " +ourIngredient);
		}
		else if (m6.find()) {
			ourYesNo = UserIntentYesNo.No;
			logger.info("set ourIngredient to " +ourIngredient);
		}
		else if (m7.find()) {
			ourYesNo = UserIntentYesNo.Yes;
			ourIngredient = UserIntentIngredient.Pasta;
			logger.info("set ourIngredient to " +ourIngredient);
		}
		else if (m8.find()) {
			ourOthers = UserIntentOthers.Thanks;
			logger.info("ich bin hier");
		}	
		else if (m9.find()) {
			ourIngredient = UserIntentIngredient.Recipe;
			ourYesNo = UserIntentYesNo.Recipe;
		}
		else if (m10.find()) {
			ourIngredient = UserIntentIngredient.Nevermind;
			ourYesNo = UserIntentYesNo.Nevermind;
		}
		
	}
	
	//Emotionen und Stimmeffekte
	
	private SpeechletResponse responseWithFlavour(String text, int i) {

		SsmlOutputSpeech speech = new SsmlOutputSpeech();
		switch(i){ 
		case 5: 
			speech.setSsml("<speak><amazon:emotion name=\"excited\" intensity=\"high\">" + text + "</amazon:emotion></speak>");
			break; 
		case 1: 
			speech.setSsml("<speak><amazon:emotion name=\"excited\" intensity=\"medium\">" + text + "</amazon:emotion></speak>");
			break; 
		case 2: 
			speech.setSsml("<speak><amazon:emotion name=\"excited\" intensity=\"low\">" + text + "</amazon:emotion></speak>");
			break; 
		case 3: 
			speech.setSsml("<speak><amazon:effect name=\"whispered\">" + text + "</amazon:effect></speak>");
			break; 
		} 

		Reprompt rep = new Reprompt();
		rep.setOutputSpeech(speech);

		return SpeechletResponse.newAskResponse(speech, rep);}
	
	

	
	@Override
	public void onSessionEnded(SpeechletRequestEnvelope<SessionEndedRequest> requestEnvelope)
	{
		logger.info("Alexa session ends now");
	}

	private SpeechletResponse askUserResponse(String text)
	{
		SsmlOutputSpeech speech = new SsmlOutputSpeech();
		if (text == welcomeMsg) {
			speech.setSsml("<speak><voice name='Matthew'>" + text + "</voice></speak>");
		} 
		else if (text == toTheMarketMsg) {
			speech.setSsml("<speak><voice name='Matthew'>" + text + "</voice></speak>");
		} 
	
		else {
			speech.setSsml("<speak><voice name='Kendra'>" + text + "</voice> </speak>");
		}
		
		logger.info(text);

		// reprompt after 8 seconds
		SsmlOutputSpeech repromptSpeech = new SsmlOutputSpeech();
		repromptSpeech.setSsml("<speak><emphasis level=\"strong\">Hey!</emphasis> Are you still there?</speak>");

		Reprompt rep = new Reprompt();
		rep.setOutputSpeech(repromptSpeech);

		return SpeechletResponse.newAskResponse(speech, rep);
	}

	private SpeechletResponse response(String text)
	{
		// Create the plain text output.
		PlainTextOutputSpeech speech = new PlainTextOutputSpeech();
		speech.setText(text);

		return SpeechletResponse.newTellResponse(speech);
	}
	private String buildString(String msg, String replacement1, String replacement2) {
		return msg.replace("{replacement}", replacement1).replace("{replacement2}", replacement2);
	}
}