package com.amazon.customskill;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.amazon.customskill.AlexaSkillSpeechlet.RecognitionState;
//import com.amazon.customskill.AlexaSkillSpeechlet.UserIntent;
import com.amazon.speech.json.SpeechletRequestEnvelope;
import com.amazon.speech.slu.Intent;
import com.amazon.speech.speechlet.IntentRequest;
import com.amazon.speech.speechlet.LaunchRequest;
import com.amazon.speech.speechlet.SessionEndedRequest;
import com.amazon.speech.speechlet.SessionStartedRequest;
import com.amazon.speech.speechlet.SpeechletResponse;
import com.amazon.speech.speechlet.SpeechletV2;
import com.amazon.speech.ui.PlainTextOutputSpeech;
import com.amazon.speech.ui.Reprompt;
import com.amazon.speech.ui.SsmlOutputSpeech;



/*
 * This class is the actual skill. Here you receive the input and have to produce the speech output. 
 */
public class AlexaSkillSpeechlet
implements SpeechletV2
{
	static Logger logger = LoggerFactory.getLogger(AlexaSkillSpeechlet.class);

	public static String userRequest;

	//Unsere Variablen

	
	private static int sum;
	private static boolean allIngredients;
	private static boolean ingredientPotatoesUsed;
	private static boolean ingredientPastaUsed;
	private static String question = "";
	private static enum RecognitionState {Answer, YesNo};
	private RecognitionState recState;
	private static enum UserIntent {Yes, No, Potatoes, Pasta, Error}; //Zun�chst allgemein Zutaten
	UserIntent ourUserIntent;

	//Feste Texte
	
	
	static String welcomeMsg = "Hello! You want to cook something for a group of friends tonight. Frankly you don't have anything left in the fridge, so you need to go to the marktet to get last minute ingridients. You can choose between pasta with tomato sauce or potatoes with gravy. What would you like to cook?";
	static String continueMsg = "Would you like to buy something else?";
	static String gotItMsg = "Thank you. I'll add it to your cart.";
	static String goodbyeMsg = "I hope you liked your experience at the best market in town.";
	static String priceMsg = "Thank you, that makes " + (sum) + "pounds please.";
	static String errorIngridients = "I didn't catch that. Which ingridient do you want?";
	static String errorQuantity = "I didn't catch that. Can you repeat the quantity?";
	static String errorYesNoMsg = "Can you repeat that?";
	static String ingridientUsedMsg = "You already bought this ingridient.";


	@Override
	public void onSessionStarted(SpeechletRequestEnvelope<SessionStartedRequest> requestEnvelope)
	{
		logger.info("Alexa session begins");
		sum = 0;
		recState = RecognitionState.Answer;
		ingredientPotatoesUsed = false;
		ingredientPastaUsed = false;
	}
	
	//Wenn das Programm startet 

	@Override
	public SpeechletResponse onLaunch(SpeechletRequestEnvelope<LaunchRequest> requestEnvelope)
	{
		ingredientPotatoesUsed = false;
		ingredientPastaUsed = false;
		selectQuestion();
		return askUserResponse(welcomeMsg);
	}
	
	// Nach jedem Einkauf wird eine neue Frage nach einer Zutat gefragt

	private void selectQuestion() {
		switch(sum){
		case 0: question = "Hey! Welcome to the best market in town. How can I help you?"; 
		case 1: question = "What would you like?"; break;
		case 2: question = "Nice Choice?"; break;
		case 3: question = "What would you like?"; break;

		}
	}

	@Override
	public SpeechletResponse onIntent(SpeechletRequestEnvelope<IntentRequest> requestEnvelope)
	{
		IntentRequest request = requestEnvelope.getRequest();
		Intent intent = request.getIntent();
		userRequest = intent.getSlot("anything").getValue();
		logger.info("Received following text: [" + userRequest + "]");
		logger.info("recState is [" + recState + "]");
		SpeechletResponse resp = null;
		switch (recState) {
		case Answer: resp = evaluateAnswer(userRequest); break;
		case YesNo: resp = evaluateYesNo(userRequest); recState = RecognitionState.Answer; break;
		default: resp = response("Erkannter Text: " + userRequest);
		}   
		return resp;
	}
	
	// Falls der Nutzer mehr einkaufen m�chte (yes), fragt Alexa eine neue Frage
	// Falls der Nutzer nichts mehr m�chte (no), gibt Alexa die Summe der Zutaten aus und die Verabschiedung
	
	private SpeechletResponse evaluateYesNo(String userRequest) {
		SpeechletResponse res = null;
		recognizeUserIntent(userRequest);
		switch (ourUserIntent) {
		case Yes: {
			selectQuestion();
			res = askUserResponse(question); break;
		} case No: {
			res = response(buildString(priceMsg, String.valueOf(sum), "")+" "+goodbyeMsg); break;
		} default: {
			res = askUserResponse(errorYesNoMsg);
		}
		}
		return res;
	}
	
	// Wenn der Nutzer eine Zutat sagt, erkennt Alexa, ob die Zutat schon eingekauft wurde
	

	private SpeechletResponse evaluateAnswer(String userRequest) {
		SpeechletResponse res = null;
		recognizeUserIntent(userRequest);
		switch (ourUserIntent) {
		case Potatoes: {
			if (ingredientPotatoesUsed) {
				res = askUserResponse(gotItMsg);
			} else {
				ingredientPotatoesUsed = true;
				res = askUserResponse((question));
			}
		}
		case Pasta: {
		
			logger.info("pasta used: "+ingredientPastaUsed) ;
			if (ingredientPastaUsed) {
					res = askUserResponse(gotItMsg);
				} else {
					ingredientPastaUsed = true;
					res = askUserResponse((question));
				}		
			}
		logger.info("pasta used: "+ingredientPastaUsed) ;
		
		
	/*case Yes: {
		if (ingredientUsed) {
				res = askUserResponse(ingridientUsedMsg);
			} else {
				//ingredientUsed = true;
				//res = askUserResponse((question));
			}		
		}
	case No: {
		if (ingredientUsed) {
				res = askUserResponse(ingridientUsedMsg);
			} else {
				//ingredientUsed = true;
				//res = askUserResponse((question));
			}		
		}
	case Error: {
		if (ingredientUsed) {
				res = askUserResponse(ingridientUsedMsg);
			} else {
				//ingredientUsed = true;
				//res = askUserResponse((question));
			}		
		}*/

		}
		
		return res;
}


	//Summe wird hochgerechnet

	private void increaseSum() {
		switch(sum){
		case 0: sum = 1; break;
		case 1: sum = 3; break;
		case 2: sum = 5; break;
		case 3: sum = 10; break;

		}
	}

	//Unsere Patterns

	void recognizeUserIntent(String userRequest) {
		userRequest = userRequest.toLowerCase();
		String pattern1 = "(I'll have )?(some )?(a few )?(\\bpotatoes\\b)( please)?";
		String pattern2= "\\bpasta\\b";
		String pattern3= "\\byes\\b";

		Pattern p1 = Pattern.compile(pattern1);
		Matcher m1 = p1.matcher(userRequest);
		Pattern p2 = Pattern.compile(pattern2);
		Matcher m2 = p2.matcher(userRequest);
		Pattern p3 = Pattern.compile(pattern3);
		Matcher m3 = p3.matcher(userRequest);
	
	
		if (m1.find()) {
			
			 ourUserIntent = UserIntent.Potatoes; 
		} 
		else if (m2.find()) {
			ourUserIntent = UserIntent.Pasta;
		}
		else {
			ourUserIntent = UserIntent.Error;
		}
		logger.info("set ourUserIntent to " +ourUserIntent);
	}



	@Override
	public void onSessionEnded(SpeechletRequestEnvelope<SessionEndedRequest> requestEnvelope)
	{
		logger.info("Alexa session ends now");
	}

	private SpeechletResponse askUserResponse(String text)
	{
		SsmlOutputSpeech speech = new SsmlOutputSpeech();
		if (text == welcomeMsg) {
			speech.setSsml("<speak><voice name='Kendra'>" + text + "</voice></speak>");
		} else {
			speech.setSsml("<speak>" + text + "</speak>");
		}

		// reprompt after 8 seconds
		SsmlOutputSpeech repromptSpeech = new SsmlOutputSpeech();
		repromptSpeech.setSsml("<speak><emphasis level=\"strong\">Hey!</emphasis> Are you still there?</speak>");

		Reprompt rep = new Reprompt();
		rep.setOutputSpeech(repromptSpeech);

		return SpeechletResponse.newAskResponse(speech, rep);
	}

	private SpeechletResponse response(String text)
	{
		// Create the plain text output.
		PlainTextOutputSpeech speech = new PlainTextOutputSpeech();
		speech.setText(text);

		return SpeechletResponse.newTellResponse(speech);
	}
	private String buildString(String msg, String replacement1, String replacement2) {
		return msg.replace("{replacement}", replacement1).replace("{replacement2}", replacement2);
	}
}